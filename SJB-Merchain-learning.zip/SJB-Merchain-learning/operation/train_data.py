import cv2
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from skimage import feature as sf


def fenge2(roi):
    # 高斯滤波
    roi = cv2.GaussianBlur(roi, (5, 5), 0)
    # 中值滤波
    roi = cv2.medianBlur(roi, 5)
    # 转换至YCrCb空间
    YCrCb = cv2.cvtColor(roi, cv2.COLOR_BGR2YCR_CB)
    # 拆分出Y,Cr,Cb值
    (y, cr, cb) = cv2.split(YCrCb)
    # 对Cr通道进行高斯模糊
    cr1 = cv2.GaussianBlur(cr, (5, 5), 0)
    # Otsu处理
    _, binary_image = cv2.threshold(cr1, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    # 定义结构元素
    kernel = np.ones((5, 5), np.uint8)
    # 闭运算
    closed_image = cv2.morphologyEx(binary_image, cv2.MORPH_CLOSE, kernel)
    # 开运算
    opened_image = cv2.morphologyEx(closed_image, cv2.MORPH_OPEN, kernel)
    return opened_image


def calculate_circularity(image):
    #计算似圆度
    # 把图像转换为灰度图
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image

    # 进行二值化处理
    _, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)

    # 查找轮廓
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if len(contours) == 0:
        return None

    # 找出面积最大的轮廓
    max_contour = max(contours, key=cv2.contourArea)

    # 计算最大轮廓的面积
    area = cv2.contourArea(max_contour)

    # 计算最大轮廓的周长
    perimeter = cv2.arcLength(max_contour, True)

    # 避免除零错误
    if perimeter == 0:
        return 0

    # 计算似圆度
    circularity = (4 * np.pi * area) / (perimeter ** 2)

    return circularity


# #查看计算值
# # path=r'D:\Users\Wald\Desktop\SJB-Merchain-learning\data\paper\IMG_20250307_203413.jpg'
# img=cv2.imread(path)
# if img is None:
#     print('none')
# else:
#     ret=fenge(img)
#     print(calculate_circularity(ret))




def calculate_hog(image):
    #提取HOG特征
    img = cv2.resize(image, (150, 150))
    hog_array = sf.hog(img, orientations=8, pixels_per_cell=(15, 15), cells_per_block=(10, 10))
    return hog_array

# #查看计算值
# path=r'D:\Users\Wald\Desktop\SJB-Merchain-learning\data\paper\IMG_20250307_203413.jpg'
# img=cv2.imread(path)
# if img is None:
#     print('none')
# else:
#     ret=fenge(img)
#     print(hog(ret))

if __name__ == '__main__':
    path = r'D:\Users\Wald\Desktop\SJB-Merchain-learning\data'
    types = ["paper", "rock", "scissors"]

    labels=[]
    cir=[]
    hogs=[]

    for label in types:
        path_img = path + '/' + label
        names = os.listdir(path_img)

        for name in names:
            img_name = path_img + '/' + name
            img = cv2.imread(img_name)
            ret = fenge2(img)
            c = calculate_circularity(ret)
            h = calculate_hog(ret)
            cir.append(c)
            hogs.append(h)
            labels.append(label)

            # 处理水平翻转后的图像
            ret_flip = cv2.flip(ret, 1)  # 水平翻转
            c_flip = calculate_circularity(ret_flip)
            h_flip = calculate_hog(ret_flip)
            cir.append(c_flip)
            hogs.append(h_flip)
            labels.append(label)

    #保存数据
    data = {u"似圆度":cir}
    hogs = np.array(hogs).reshape(len(hogs), -1)
    label_dict = {u"类别": labels}

    df = pd.DataFrame(data)
    hog_df = pd.DataFrame(hogs)
    label_df = pd.DataFrame(label_dict)
    df = pd.concat([label_df, df, hog_df], axis=1)
    # 注意csv需要使用gbk编码
    df.to_csv(r"D:\Users\Wald\Desktop\SJB-Merchain-learning\operation\features2.csv", index=0, encoding="gbk")

