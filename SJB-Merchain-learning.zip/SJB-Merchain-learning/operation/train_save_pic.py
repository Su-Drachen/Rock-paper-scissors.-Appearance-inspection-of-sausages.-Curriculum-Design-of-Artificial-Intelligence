import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn import model_selection
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt


def main():
	try:
		# 读取数据
		data = pd.read_csv(r'D:\Users\Wald\Desktop\SJB-Merchain-learning\operation\features2.csv', encoding="gbk")
	except FileNotFoundError:
		print("文件未找到，请检查文件路径。")
		return
	except Exception as e:
		print(f"读取文件时出现错误: {e}")
		return

	# 将类别转换为索引
	data.loc[data["类别"] == "paper", "类别"] = 0
	data.loc[data["类别"] == "scissors", "类别"] = 1
	data.loc[data["类别"] == "rock", "类别"] = 2

	x_data = data.iloc[:, 2:].to_numpy(np.float32)  # 数据
	y_data = data["类别"].to_numpy(dtype=np.int32)  # 标签

	# 分割训练集和测试集
	train_data, test_data, train_label, test_label = model_selection.train_test_split(
		x_data, y_data, random_state=1, test_size=0.25, train_size=0.75
	)

	# 转换为DMatrix格式
	dtrain = xgb.DMatrix(train_data, label=train_label)
	dtest = xgb.DMatrix(test_data, label=test_label)  # 添加测试集标签（用于评估）

	# 定义评估集和参数
	evals = [(dtrain, 'train'), (dtest, 'test')]
	params = {
		'objective': 'multi:softmax',
		'num_class': 3,
		'eval_metric': ['merror', 'mlogloss'],
		'max_depth': 3,
		'eta': 0.1,
		'subsample': 0.8,
		'colsample_bytree': 0.8
	}

	# 存储训练过程评估结果
	evals_result = {}

	# 训练模型并记录过程（修正重复训练问题）
	num_rounds = 200
	model = xgb.train(
		params,
		dtrain,
		num_rounds,
		evals=evals,
		evals_result=evals_result,
		verbose_eval=1  # 打印每轮训练信息
	)

	# 预测并计算最终准确率
	y_pred = model.predict(dtest)
	accuracy = accuracy_score(test_label, y_pred)
	print(f"Test Accuracy: {accuracy * 100:.2f}%")

	# 提取训练过程数据
	iterations = range(1, num_rounds + 1)  # 迭代次数从1开始计数

	# 损失函数数据（mlogloss）
	train_loss = evals_result['train']['mlogloss']
	test_loss = evals_result['test']['mlogloss']

	# 准确率数据（1 - merror）
	train_accuracy = [1 - err for err in evals_result['train']['merror']]
	test_accuracy = [1 - err for err in evals_result['test']['merror']]

	# 创建画布
	plt.figure(figsize=(16, 6))

	# 绘制损失曲线
	plt.subplot(1, 2, 1)
	plt.plot(iterations, train_loss, 'bo-', label='Train Loss')
	plt.plot(iterations, test_loss, 'ro-', label='Test Loss')
	plt.xlabel('Iteration')
	plt.ylabel('Loss (mlogloss)')
	plt.title('Training Process Loss Curve')
	plt.legend()
	plt.grid(linestyle='--', alpha=0.7)

	# 绘制准确率曲线
	plt.subplot(1, 2, 2)
	plt.plot(iterations, train_accuracy, 'g^-', label='Train Accuracy')
	plt.plot(iterations, test_accuracy, 'm^-', label='Test Accuracy')
	plt.xlabel('Iteration')
	plt.ylabel('Accuracy')
	plt.title('Training Process Accuracy Curve')
	plt.legend()
	plt.grid(linestyle='--', alpha=0.7)

	plt.tight_layout()
	plt.show()


if __name__ == "__main__":
	main()
