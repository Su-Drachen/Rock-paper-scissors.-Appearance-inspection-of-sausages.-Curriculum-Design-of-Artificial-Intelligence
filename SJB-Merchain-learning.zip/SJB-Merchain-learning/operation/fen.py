import cv2
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from skimage import feature as sf


def fenge(image):
    # 转换颜色空间
    img = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
    h_channel, s_channel, v_channel = cv2.split(img)
    # OTSU阈值分割
    t, img = cv2.threshold(h_channel, 20, 255, cv2.THRESH_OTSU)
    # 对二值图像进行去噪操作
    # 开运算
    kernel = np.ones((3, 3), np.uint8)
    img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel, iterations=3)
    # 中值滤波
    img = cv2.medianBlur(img, 7)

    # 找到所有轮廓
    contours, _ = cv2.findContours(img.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if len(contours) > 0:
        # 计算每个轮廓的面积
        areas = [cv2.contourArea(c) for c in contours]
        # 找到面积最大的轮廓的索引
        max_area_index = np.argmax(areas)
        # 创建一个空白图像
        max_area_img = np.zeros_like(img)
        # 在空白图像上绘制面积最大的轮廓
        cv2.drawContours(max_area_img, [contours[max_area_index]], -1, 255, thickness=cv2.FILLED)
        img = max_area_img



    return img

####YCrCb颜色空间的Cr分量+Otsu法阈值分割算法
# def fenge2(roi):
# 	YCrCb = cv2.cvtColor(roi, cv2.COLOR_BGR2YCR_CB)  # 转换至YCrCb空间
# 	(y, cr, cb) = cv2.split(YCrCb)  # 拆分出Y,Cr,Cb值
# 	cr1 = cv2.GaussianBlur(cr, (5, 5), 0)
# 	_, skin = cv2.threshold(cr1, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)  # Ostu处理
# 	res = cv2.bitwise_and(roi, roi, mask=skin)
# 	return res
def fenge2(roi):
    # 高斯滤波
    roi = cv2.GaussianBlur(roi, (5, 5), 0)
    # 中值滤波
    roi = cv2.medianBlur(roi, 5)
    # 转换至YCrCb空间
    YCrCb = cv2.cvtColor(roi, cv2.COLOR_BGR2YCR_CB)
    # 拆分出Y,Cr,Cb值
    (y, cr, cb) = cv2.split(YCrCb)
    # 对Cr通道进行高斯模糊
    cr1 = cv2.GaussianBlur(cr, (5, 5), 0)
    # Otsu处理
    _, binary_image = cv2.threshold(cr1, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    # 定义结构元素
    kernel = np.ones((5, 5), np.uint8)
    # 闭运算
    closed_image = cv2.morphologyEx(binary_image, cv2.MORPH_CLOSE, kernel)
    # 开运算
    opened_image = cv2.morphologyEx(closed_image, cv2.MORPH_OPEN, kernel)
    return opened_image

# #查看提取效果
# path=r'D:\Users\Wald\Desktop\SJB-Merchain-learning\ttt\paper\paper7.png'
# img=cv2.imread(path)
# if img is None:
#     print('none')
# else:
#     ret=fenge2(img)
#     ret_flip = cv2.flip(ret, 1)  # 水平翻转
#     # 显示图像,仅为测试使用
#     fig, axes = plt.subplots(1, 1, figsize=(10, 10))
#     axes.imshow(ret, cmap='gray')
#     axes.set_title('Image')
#     axes.axis('off')
#     plt.show()
#
#     # 显示图像,仅为测试使用
#     fig, axes = plt.subplots(1, 1, figsize=(10, 10))
#     axes.imshow(ret_flip, cmap='gray')
#     axes.set_title('Image')
#     axes.axis('off')
#     plt.show()


