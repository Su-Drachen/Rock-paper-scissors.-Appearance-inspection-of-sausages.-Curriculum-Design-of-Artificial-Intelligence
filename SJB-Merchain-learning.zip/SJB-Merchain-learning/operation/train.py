import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn import model_selection
from sklearn.metrics import accuracy_score

if __name__ == "__main__":
    try:
        # 读取数据
        data = pd.read_csv(r'D:\Users\Wald\Desktop\SJB-Merchain-learning\operation\features2.csv', encoding="gbk")
    except FileNotFoundError:
        print("文件未找到，请检查文件路径。")
        import sys
        sys.exit(1)
    except Exception as e:
        print(f"读取文件时出现错误: {e}")
        import sys
        sys.exit(1)

    # 将类别转换为索引
    data.loc[data["类别"] == "paper", "类别"] = 0
    data.loc[data["类别"] == "scissors", "类别"] = 1
    data.loc[data["类别"] == "rock", "类别"] = 2

    x_data = data.iloc[:, 2:].to_numpy(np.float32)  # 数据
    y_data = data["类别"].to_numpy(dtype=np.int32)  # 标签

    # 分割训练集和测试集，分别为75%和25%
    train_data, test_data, train_label, test_label = model_selection.train_test_split(
        x_data, y_data, random_state=1, test_size=0.25, train_size=0.75)

    # 将数据转换为DMatrix格式
    dtrain = xgb.DMatrix(train_data, label=train_label)
    dtest = xgb.DMatrix(test_data)

    # 定义XGBOOST分类器
    params = {
        'objective': 'multi:softmax',
        'num_class': 3,
        'eval_metric': 'merror',
        'max_depth': 3,
        'eta': 0.1,
        'subsample': 0.8,
        'colsample_bytree': 0.8
    }

    # 训练模型
    num_rounds = 200
    model = xgb.train(params, dtrain, num_rounds)

    # 保存模型
    model.save_model('rps_model_2.0.model')

    # 进行预测
    y_pred = model.predict(dtest)

    # 计算准确率
    accuracy = accuracy_score(test_label, y_pred)
    print(f"Accuracy: {accuracy*100:.2f}")

    # # 加载模型进行预测（示例）
    # loaded_model = xgb.Booster()
    # loaded_model.load_model('rps_model.model')
    # new_pred = loaded_model.predict(dtest)
    # print(f"Predictions from loaded model: {new_pred}")