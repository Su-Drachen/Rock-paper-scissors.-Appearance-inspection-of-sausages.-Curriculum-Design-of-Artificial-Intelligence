import cv2
import os


def resize_rename(path, prefix):
    # 初始化编号
    count = 1
    # 遍历所有文件
    for filename in os.listdir(path):
        # 获取文件的完整路径
        file_path = os.path.join(path, filename)
        # 检查是否为文件
        if os.path.isfile(file_path):
            try:
                # 修改图片像素为300*300
                image = cv2.imread(file_path,cv2.IMREAD_UNCHANGED)
                if image is not None:
                    resize_image = cv2.resize(image, (300, 300), interpolation=cv2.INTER_AREA)
                    # 获取文件的扩展名
                    file_extension = '.png'
                    # 构建新的文件名
                    new_filename = f"{prefix}{count}{file_extension}"
                    # 构建新的文件完整路径
                    new_file_path = os.path.join(path, new_filename)
                    # 保存修改后的图片
                    cv2.imwrite(new_file_path, resize_image)
                    # 删除原文件
                    os.remove(file_path)
                    # 编号加 1
                    count += 1
            except Exception as e:
                print(f"处理文件 {filename} 时出现错误: {e}")




# 预处理，修改输入图片的名称和大小
path = r'D:\Users\Wald\Desktop\SJB-Merchain-learning\ttt\paper'
resize_rename(path, 'paper')

path = r'D:\Users\Wald\Desktop\SJB-Merchain-learning\ttt\rock'
resize_rename(path, 'rock')

path = r'D:\Users\Wald\Desktop\SJB-Merchain-learning\ttt\scissors'
resize_rename(path, 'scissors')

