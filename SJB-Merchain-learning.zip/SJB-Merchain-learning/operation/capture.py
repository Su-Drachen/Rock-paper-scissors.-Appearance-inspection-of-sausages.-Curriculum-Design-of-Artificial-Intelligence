import cv2
import os

# 指定保存照片的文件夹路径，你可以根据需要修改
choose=2
if choose==0:
	save_folder = r'D:\Users\Wald\Desktop\SJB-Merchain-learning\ttt\paper'
elif choose==1:
	save_folder = r'D:\Users\Wald\Desktop\SJB-Merchain-learning\ttt\rock'
else:
	save_folder = r'D:\Users\Wald\Desktop\SJB-Merchain-learning\ttt\scissors'
# 如果保存文件夹不存在，则创建它
if not os.path.exists(save_folder):
	os.makedirs(save_folder)

# 打开摄像头
cap = cv2.VideoCapture(0)

while True:
	# 读取摄像头帧
	ret, frame = cap.read()
	if not ret:
		print("无法读取摄像头帧")
		break

	# 定义选取框的大小和位置（左上角）
	box_size = 300
	x1 = 0
	y1 = 0
	x2 = box_size
	y2 = box_size

	# 绘制选取框
	cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

	# 显示当前帧
	cv2.imshow('Press to capture', frame)

	# 等待按键事件
	key = cv2.waitKey(1)

	# 如果按下 回车 键
	if key == 32:
		# 提取选取框内的图像
		roi = frame[y1:y2, x1:x2]

		# 调整图像大小为 300x300（确保尺寸一致）
		resized_frame = cv2.resize(roi, (300, 300))

		# 生成照片文件名
		photo_count = len(os.listdir(save_folder))
		photo_name = os.path.join(save_folder, f'test_photo_{photo_count + 1}.jpg')

		# 保存照片
		cv2.imwrite(photo_name, resized_frame)
		print(f'照片已保存到 {photo_name}')

	# 如果按下 ESC 键，退出循环
	elif key == 27:
		break

# 释放摄像头并关闭窗口
cap.release()
cv2.destroyAllWindows()
