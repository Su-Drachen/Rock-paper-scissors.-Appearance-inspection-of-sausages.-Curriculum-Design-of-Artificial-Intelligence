import cv2
import numpy as np
import xgboost as xgb
import os
import pandas as pd
from sklearn.metrics import accuracy_score
from operation.train_data import *

# 加载模型
def load_model(model_path):
    """
    加载保存的 XGBoost 模型
    :param model_path: 模型文件的路径
    :return: 加载好的模型
    """
    model = xgb.Booster()
    model.load_model(model_path)
    return model

# 定义分类函数
def classify_image(path, model):

    types = ["paper", "rock", "scissors"]
    labels = []
    cir = []
    hogs = []
    image_paths = []

    for label in types:
        path_img = path + '/' + label
        names = os.listdir(path_img)

        for name in names:
            img_name = path_img + '/' + name
            image_paths.append(img_name)
            img = cv2.imread(img_name)
            ret = fenge2(img)
            c = calculate_circularity(ret)
            h = calculate_hog(ret)
            cir.append(c)
            hogs.append(h)
            labels.append(label)

    # 保存数据
    data = {u"似圆度": cir}
    hogs = np.array(hogs).reshape(len(hogs), -1)
    label_dict = {u"类别": labels}

    df = pd.DataFrame(data)
    hog_df = pd.DataFrame(hogs)
    label_df = pd.DataFrame(label_dict)
    data = pd.concat([label_df, df, hog_df], axis=1)

    # 将类别转换为索引
    data.loc[data["类别"] == "paper", "类别"] = 0
    data.loc[data["类别"] == "scissors", "类别"] = 1
    data.loc[data["类别"] == "rock", "类别"] = 2

    x_data = data.iloc[:, 2:].to_numpy(np.float32)  # 数据
    y_data = data["类别"].to_numpy(dtype=np.int32)  # 标签

    rows, cols = x_data.shape

    # 转换为 DMatrix 格式
    dmatrix = xgb.DMatrix(x_data)

    # 进行预测
    prediction = model.predict(dmatrix)

    # 计算准确率
    accuracy = accuracy_score(y_data, np.round(prediction).astype(int))
    print(f"Accuracy: {accuracy * 100:.2f}%")

    # 打印每个样本的预测结果
    type_mapping = {0: "paper", 1: "scissors", 2: "rock"}
    prediction = np.round(prediction).astype(int)  # 将预测结果转换为整数
    for i in range(len(y_data)):
        predicted_label = type_mapping[prediction[i]]
        print(f"图片 {image_paths[i]} 的预测类别: {predicted_label}")


if __name__ == '__main__':
    # 模型路径
    model = load_model(r'D:\Users\Wald\Desktop\SJB-Merchain-learning\operation\rps_model_2.0.model')
    # 数据路径 D:\Users\Wald\Desktop\SHOUSHI
    data_path = r'D:\Users\Wald\Desktop\SHOUSHI'
    classify_image(data_path, model)