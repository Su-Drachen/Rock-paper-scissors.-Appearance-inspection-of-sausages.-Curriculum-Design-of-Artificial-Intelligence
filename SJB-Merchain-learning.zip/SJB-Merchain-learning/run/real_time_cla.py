import cv2
import numpy as np
import xgboost as xgb
import pandas as pd
from joblib import delayed

from operation.fen import *
from operation.train_data import *


# 加载模型
def load_model(model_path):
	"""
	加载保存的 XGBoost 模型
	:param model_path: 模型文件的路径
	:return: 加载好的模型
	"""
	model = xgb.Booster()
	model.load_model(model_path)
	return model


# 定义实时识别函数
def real_time_recognition(model):
	types = ["paper", "rock", "scissors"]
	type_mapping = {0: "paper", 1: "scissors", 2: "rock"}

	# 打开摄像头
	cap = cv2.VideoCapture(0)

	while True:
		# 读取摄像头帧
		ret, frame = cap.read()
		if not ret:
			print("无法读取摄像头帧")
			break

		# 获取帧的高度和宽度
		height, width, _ = frame.shape

		# 定义识别框的大小和位置（将框放在画面左上角）
		box_size = 300
		x1 = 0
		y1 = 0
		x2 = box_size
		y2 = box_size

		# 绘制识别框
		cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

		# 提取框内的图像
		roi = frame[y1:y2, x1:x2]

		# 处理框内图像
		ret = fenge2(roi)
		cir = []
		hogs = []
		labels = []
		c = calculate_circularity(ret)
		h = calculate_hog(ret)

		cir.append(c)
		hogs.append(h)
		labels.append("test")

		# 准备数据
		# 保存数据
		data = {u"似圆度": cir}
		hogs = np.array(hogs).reshape(len(hogs), -1)
		label_dict = {u"类别": labels}
		label_df = pd.DataFrame(label_dict)

		df = pd.DataFrame(data)
		hog_df = pd.DataFrame(hogs)
		data = pd.concat([label_df,df, hog_df], axis=1)

		# 将类别转换为索引
		data.loc[data["类别"] == "paper", "类别"] = 0
		data.loc[data["类别"] == "scissors", "类别"] = 1
		data.loc[data["类别"] == "rock", "类别"] = 2

		x_data = data.iloc[:,2:].to_numpy(np.float32)  # 数据

		# 转换为 DMatrix 格式
		dmatrix = xgb.DMatrix(x_data)

		# 进行预测
		prediction = model.predict(dmatrix)

		prediction = np.round(prediction).astype(int)  # 将预测结果转换为整数
		type_mapping = {0: "paper", 1: "scissors", 2: "rock"}
		predicted_label = type_mapping[prediction[len(prediction)-1]]

		# 在帧上显示预测结果
		cv2.putText(frame, f"Prediction: {predicted_label}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

		# 显示 fenge() 函数处理后的图像
		cv2.imshow('fenge', ret)


		# 显示帧
		cv2.imshow('Real-time Recognition', frame)

		# 按 ESC 键退出循环
		if cv2.waitKey(1) & 0xFF ==  27:
			break

		rows,columns = x_data.shape[0], x_data.shape[1]

		delayed(50)

	# 释放摄像头并关闭窗口
	cap.release()
	cv2.destroyAllWindows()


if __name__ == '__main__':
	# 模型路径
	model = load_model(r'D:\Users\Wald\Desktop\SJB-Merchain-learning\operation\rps_model_2.0.model')
	# 开始实时识别
	real_time_recognition(model)
